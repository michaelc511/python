"""One-off: render copilot_report.md to copilot_report.pdf"""
from pathlib import Path

from fpdf import FPDF

MD_PATH = Path(__file__).parent / "copilot_report.md"
PDF_PATH = Path(__file__).parent / "copilot_report.pdf"


class ReportPDF(FPDF):
    def __init__(self):
        super().__init__()
        self.set_auto_page_break(auto=True, margin=15)

    def write_line(self, text: str, size: int = 11, style: str = ""):
        self.set_font("Helvetica", style, size)
        self.multi_cell(0, 6, text)
        self.ln(2)


def main():
    text = MD_PATH.read_text(encoding="utf-8")
    pdf = ReportPDF()
    pdf.add_page()

    for raw in text.splitlines():
        line = raw.rstrip()
        if not line:
            pdf.ln(2)
            continue
        if line.startswith("# "):
            pdf.set_font("Helvetica", "B", 16)
            pdf.multi_cell(0, 8, line[2:].strip())
            pdf.ln(4)
        elif line.startswith("## "):
            pdf.set_font("Helvetica", "B", 13)
            pdf.multi_cell(0, 7, line[3:].strip())
            pdf.ln(2)
        elif line.startswith("- "):
            pdf.set_font("Helvetica", "", 11)
            pdf.multi_cell(0, 6, "  - " + line[2:].strip())
            pdf.ln(1)
        else:
            pdf.set_font("Helvetica", "", 11)
            pdf.multi_cell(0, 6, line)
            pdf.ln(1)

    pdf.output(str(PDF_PATH))
    print(f"Wrote {PDF_PATH}")


if __name__ == "__main__":
    main()
